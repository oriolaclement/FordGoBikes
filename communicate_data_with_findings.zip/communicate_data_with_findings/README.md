# Ford GoBike System Data exploration project
#### BY Oriola Timilehin



## Dataset

> This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area.


## Summary of Findings
- It became obvious to us that Thursday tends to be the day with the most trips and it is the male gender that goes out more on a trip on that particular day and not only that, users tends to go on a trip during the weekdays and they are more of subscribers than customer whose age ranges falls between 25-30 years. 


## Key Insights for Presentation

- After our analysis, it became obvious to us that Thursday tends to be the day with the most trips and it is the male gender that goes out more on a trip on that particular day.
- it was also observed that the start station with the most ride is Market Street at 10th Street which tells us that the services rendered their on getting a successful trip is high.
- Also a pattern was traced that lead us to figure out that we have more user of the subscribers than that of the customers which shows that the subscribers are member users and the customers are casual users.
- Finally it was discovered that most of the subscribers are mostly the male gender.